/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_326()
{
    return 3277383695U;
}

void setval_342(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_155(unsigned x)
{
    return x + 3284634952U;
}

unsigned addval_443(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_478()
{
    return 3284633928U;
}

unsigned addval_143(unsigned x)
{
    return x + 3281031192U;
}

unsigned addval_225(unsigned x)
{
    return x + 2425394264U;
}

unsigned addval_322(unsigned x)
{
    return x + 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_148()
{
    return 3227566729U;
}

unsigned getval_417()
{
    return 2464188744U;
}

unsigned addval_206(unsigned x)
{
    return x + 3286272330U;
}

unsigned addval_304(unsigned x)
{
    return x + 3675832969U;
}

unsigned getval_386()
{
    return 2447411528U;
}

unsigned addval_268(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_267()
{
    return 3223372425U;
}

void setval_133(unsigned *p)
{
    *p = 3385115273U;
}

unsigned getval_240()
{
    return 3375943305U;
}

unsigned getval_411()
{
    return 3251734881U;
}

unsigned addval_110(unsigned x)
{
    return x + 2425540233U;
}

unsigned getval_471()
{
    return 3676361161U;
}

unsigned addval_236(unsigned x)
{
    return x + 3523793289U;
}

unsigned addval_345(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_104(unsigned x)
{
    return x + 3531919753U;
}

void setval_396(unsigned *p)
{
    *p = 3381972617U;
}

void setval_154(unsigned *p)
{
    *p = 2446231920U;
}

unsigned addval_427(unsigned x)
{
    return x + 3374370473U;
}

unsigned getval_451()
{
    return 3285100864U;
}

unsigned addval_430(unsigned x)
{
    return x + 3281047817U;
}

unsigned getval_318()
{
    return 2429454386U;
}

unsigned addval_401(unsigned x)
{
    return x + 3221799593U;
}

void setval_224(unsigned *p)
{
    *p = 3252717896U;
}

void setval_316(unsigned *p)
{
    *p = 3281179017U;
}

unsigned getval_238()
{
    return 2463205837U;
}

unsigned getval_298()
{
    return 3229929097U;
}

unsigned getval_254()
{
    return 3526935177U;
}

void setval_462(unsigned *p)
{
    *p = 3381969545U;
}

unsigned getval_341()
{
    return 2428684652U;
}

unsigned addval_474(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_344()
{
    return 3286272332U;
}

unsigned addval_130(unsigned x)
{
    return x + 3281047949U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
